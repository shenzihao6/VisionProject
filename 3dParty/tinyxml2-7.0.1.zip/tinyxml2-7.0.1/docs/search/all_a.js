var searchData=
[
  ['name',['Name',['../classtinyxml2_1_1_x_m_l_attribute.html#ab886c486ec19f02ed826f8dc129e5ad8',1,'tinyxml2::XMLAttribute::Name()'],['../classtinyxml2_1_1_x_m_l_element.html#a63e057fb5baee1dd29f323cb85907b35',1,'tinyxml2::XMLElement::Name()']]],
  ['newcomment',['NewComment',['../classtinyxml2_1_1_x_m_l_document.html#ade4874bcb439954972ef2b3723ff3259',1,'tinyxml2::XMLDocument']]],
  ['newdeclaration',['NewDeclaration',['../classtinyxml2_1_1_x_m_l_document.html#aee2eb3435923f5494dcc70ac225b60a2',1,'tinyxml2::XMLDocument']]],
  ['newelement',['NewElement',['../classtinyxml2_1_1_x_m_l_document.html#a8aa7817d4a1001364b06373763ab99d6',1,'tinyxml2::XMLDocument']]],
  ['newtext',['NewText',['../classtinyxml2_1_1_x_m_l_document.html#ab7e8b29ae4099092a8bb947da6361296',1,'tinyxml2::XMLDocument']]],
  ['newunknown',['NewUnknown',['../classtinyxml2_1_1_x_m_l_document.html#a5385c937734ff6db9226ab707d2c7147',1,'tinyxml2::XMLDocument']]],
  ['next',['Next',['../classtinyxml2_1_1_x_m_l_attribute.html#aee53571b21e7ce5421eb929523a8bbe6',1,'tinyxml2::XMLAttribute']]],
  ['nextsibling',['NextSibling',['../classtinyxml2_1_1_x_m_l_node.html#a79db9ef0fe014d27790f2218b87bcbb5',1,'tinyxml2::XMLNode::NextSibling()'],['../classtinyxml2_1_1_x_m_l_handle.html#aad2eccc7c7c7b18145877c978c3850b5',1,'tinyxml2::XMLHandle::NextSibling()']]],
  ['nextsiblingelement',['NextSiblingElement',['../classtinyxml2_1_1_x_m_l_node.html#a1264c86233328f0cd36297552d982f80',1,'tinyxml2::XMLNode::NextSiblingElement()'],['../classtinyxml2_1_1_x_m_l_handle.html#ae41d88ee061f3c49a081630ff753b2c5',1,'tinyxml2::XMLHandle::NextSiblingElement()']]],
  ['nochildren',['NoChildren',['../classtinyxml2_1_1_x_m_l_node.html#ac3ab489e6e202a3cd1762d3b332e89d4',1,'tinyxml2::XMLNode']]]
];
